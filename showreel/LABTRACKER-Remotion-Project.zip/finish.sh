#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
duration=$(python3 -c 'import json;t=json.load(open("timing.json"));print(t["frames"]/t["fps"])')
ffmpeg -hide_banner -f concat -safe 0 -i out/concat.txt -i out/master-v2.m4a -map 0:v:0 -map 1:a:0 -vf 'setpts=N/(30*TB)' -r 30 -fps_mode cfr -c:v libx264 -preset fast -crf 18 -threads 3 -c:a copy -t "$duration" -movflags +faststart out/LABTRACKER-v2.mp4
