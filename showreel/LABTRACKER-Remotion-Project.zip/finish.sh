#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
# Build out/master.m4a with master_audio.py and FFmpeg as documented in README.
ffmpeg -hide_banner -loglevel error -i out/LABTRACKER-Showreel.mp4 -i out/master.m4a -map 0:v:0 -map 1:a:0 -c copy -movflags +faststart -t 288 -y out/LABTRACKER-Final.mp4
