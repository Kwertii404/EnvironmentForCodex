import json,subprocess,os,soundfile as sf,numpy as np
beats=json.load(open('beats.json'));os.makedirs('out/unpaced',exist_ok=True);scenes=[];cursor=0
for i,lines in enumerate(beats):
 cues=[];pos=20/30
 for j,line in enumerate(lines):
  p=f'public/vo-{i}-{j}.wav';original=f'out/unpaced/vo-{i}-{j}.wav'
  if not os.path.exists(original):os.rename(p,original)
  subprocess.run(['ffmpeg','-v','error','-i',original,'-af','atempo=1.06','-y',p],check=True)
  d=sf.info(p).duration;cues.append({'start':round(pos*30),'duration':d,'file':p.split('/')[-1],'text':line});pos+=d+.24
 frames=int(np.ceil((pos+.7)*30));scenes.append({'index':i,'from':cursor,'frames':frames,'cues':cues});cursor+=frames
json.dump({'frames':cursor,'fps':30,'scenes':scenes},open('timing.json','w'),indent=2)
print('Duration',cursor/30,'seconds')
assert 240<=cursor/30<=300
