import json,subprocess,pathlib
T=json.load(open('timing.json'));src='/workspace/LABTRACKER-Showreel.mp4'
for s in T['scenes']:
 i=s['index'];p=f'out/scene-{i:02}.mp4'
 if pathlib.Path(p).exists():continue
 cuts=[0,s['cues'][1]['start'],s['cues'][2]['start'],s['frames']];old=[0,340,500,720];chains=[]
 for k in range(3):
  dur=cuts[k+1]-cuts[k];ratio=dur/(old[k+1]-old[k]);chains.append(f'[s{k}]trim=start_frame={old[k]}:end_frame={old[k+1]},setpts=(PTS-STARTPTS)*{ratio:.9f},fps=30,tpad=stop_mode=clone:stop_duration=1,trim=end_frame={dur},setpts=PTS-STARTPTS[v{k}]')
 filt='[0:v]split=3[s0][s1][s2];'+';'.join(chains)+';[v0][v1][v2]concat=n=3:v=1:a=0[v]'
 subprocess.run(['ffmpeg','-v','error','-ss',str(i*24),'-t','24','-i',src,'-filter_complex',filt,'-map','[v]','-an','-c:v','libx264','-preset','fast','-crf','18','-threads','2','-video_track_timescale','15360','-y',p],check=True)
 print('Edited scene',i,s['frames'],flush=True)
open('out/concat.txt','w').write(''.join(f"file 'scene-{i:02}.mp4'\n" for i in range(12)))
