import numpy as np, soundfile as sf
sr=32000; dur=288; beat=.6
out=np.zeros((dur*sr,2),np.float32); rng=np.random.default_rng(7)
def add(t,a,pan=0):
 s=int(t*sr); n=min(len(a),len(out)-s)
 if n>0:
  out[s:s+n,0]+=a[:n]*(.7-pan*.25);out[s:s+n,1]+=a[:n]*(.7+pan*.25)
chords=[[146.83,174.61,220,261.63],[130.81,164.81,196,246.94],[110,130.81,164.81,196],[98,123.47,146.83,174.61]]
for bar in range(120):
 start=bar*beat*4
 chord=chords[(bar//2)%4]
 # evolving soft pad
 t=np.arange(int(beat*4.1*sr))/sr;env=np.minimum(t/.35,1)*np.maximum(0,1-t/(beat*4.1))
 a=sum(np.sin(2*np.pi*f*t+.15*np.sin(t*.7)) for f in chord)*env*.027
 add(start,a)
 for b in range(4):
  at=start+b*beat
  t=np.arange(int(.35*sr))/sr
  kick=np.sin(2*np.pi*(48*t+7*(1-np.exp(-t*25))))*np.exp(-t*16)*.18
  if bar>3:add(at,kick)
  t=np.arange(int(.18*sr))/sr
  bass=np.sin(2*np.pi*chord[0]/2*t)*np.exp(-t*12)*.09
  add(at,bass)
  if b in [1,3] and bar>7:
   t=np.arange(int(.12*sr))/sr;add(at,rng.normal(0,.035,len(t))*np.exp(-t*40))
 for n in range(8):
  at=start+n*beat/2;t=np.arange(int(.5*sr))/sr;f=chord[[0,2,1,3,2,1,3,2][n]]*2
  a=(np.sin(2*np.pi*f*t)+.25*np.sin(2*np.pi*f*2*t))*np.exp(-t*8)*.048
  add(at,a,np.sin(bar+n));add(at+.225,a*.25,-np.sin(bar+n))
  if bar>7:
   t=np.arange(int(.045*sr))/sr;add(at+.3,rng.normal(0,.022,len(t))*np.exp(-t*100),.4)
# soft transition swells
for at in range(24,288,24):
 t=np.arange(sr)/sr;a=rng.normal(0,.014,sr)*np.sin(np.pi*t)**2;add(at-.7,a)
fade=np.minimum(np.arange(len(out))/(sr*3),1)*np.minimum((len(out)-np.arange(len(out)))/(sr*5),1)
out*=fade[:,None]
sf.write('public/music.wav',out,sr)
print('Original 100 BPM instrumental: 288 seconds')
