import React from 'react';
import {Freeze,Sequence,staticFile,interpolate,useCurrentFrame,useVideoConfig} from 'remotion';
import {Audio} from '@remotion/media';
import timing from '../timing.json';
import {VisualChapter} from './Design';
export const Chapter=({index}:{index:number})=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();const scene=timing.scenes[index];
 const mapped=interpolate(frame,[0,scene.cues[1].start,scene.cues[2].start,scene.frames],[0,340,500,720],{extrapolateRight:'clamp'});
 return <><Freeze frame={Math.min(719,Math.floor(mapped))}><VisualChapter index={index}/></Freeze>
 <Sequence from={scene.cues[0].start} premountFor={fps}><Audio src={staticFile(scene.cues[0].file)} premountFor={fps}/></Sequence>
 <Sequence from={scene.cues[1].start} premountFor={fps}><Audio src={staticFile(scene.cues[1].file)} premountFor={fps}/></Sequence>
 <Sequence from={scene.cues[2].start} premountFor={fps}><Audio src={staticFile(scene.cues[2].file)} premountFor={fps}/></Sequence>
 </>;
};
