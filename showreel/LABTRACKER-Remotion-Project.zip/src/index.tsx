import React from 'react';
import {registerRoot,Composition,Series,AbsoluteFill,staticFile,useVideoConfig,interpolate} from 'remotion';
import {Audio} from '@remotion/media';
import {Chapter} from './Scene';
const Film=()=>{const {fps}=useVideoConfig();return <AbsoluteFill><Series>
<Series.Sequence name="Meet LABTRACKER" durationInFrames={680} premountFor={fps}><Chapter index={0}/></Series.Sequence>
<Series.Sequence name="Connected workspace" durationInFrames={782} premountFor={fps}><Chapter index={1}/></Series.Sequence>
<Series.Sequence name="Equipment" durationInFrames={665} premountFor={fps}><Chapter index={2}/></Series.Sequence>
<Series.Sequence name="Add equipment" durationInFrames={708} premountFor={fps}><Chapter index={3}/></Series.Sequence>
<Series.Sequence name="Search and filter" durationInFrames={716} premountFor={fps}><Chapter index={4}/></Series.Sequence>
<Series.Sequence name="Maintenance" durationInFrames={742} premountFor={fps}><Chapter index={5}/></Series.Sequence>
<Series.Sequence name="Log the work" durationInFrames={703} premountFor={fps}><Chapter index={6}/></Series.Sequence>
<Series.Sequence name="Laboratories" durationInFrames={722} premountFor={fps}><Chapter index={7}/></Series.Sequence>
<Series.Sequence name="Categories" durationInFrames={693} premountFor={fps}><Chapter index={8}/></Series.Sequence>
<Series.Sequence name="Accounts" durationInFrames={739} premountFor={fps}><Chapter index={9}/></Series.Sequence>
<Series.Sequence name="Connected workflow" durationInFrames={800} premountFor={fps}><Chapter index={10}/></Series.Sequence>
<Series.Sequence name="Keep moving forward" durationInFrames={823} premountFor={fps}><Chapter index={11}/></Series.Sequence>
</Series><Audio src={staticFile('music-v2.wav')} premountFor={fps} volume={f=>interpolate(f,[0,30,8713,8773],[.3,.21,.21,0],{extrapolateRight:'clamp'})}/></AbsoluteFill>};
registerRoot(()=> <><Composition id="LabTracker" component={Film} durationInFrames={8773} fps={30} width={1920} height={1080}/><Composition id="Equipment" component={Chapter} defaultProps={{index:2}} durationInFrames={665} fps={30} width={1920} height={1080}/><Composition id="Maintenance" component={Chapter} defaultProps={{index:5}} durationInFrames={742} fps={30} width={1920} height={1080}/></>);
