import React from 'react';
import {registerRoot,Composition,Series,AbsoluteFill,staticFile,useVideoConfig,interpolate} from 'remotion';
import {Audio} from '@remotion/media';
import {Chapter} from './Design';
const Film=()=>{const {fps}=useVideoConfig();return <AbsoluteFill><Series>
<Series.Sequence name="Meet LABTRACKER" durationInFrames={720} premountFor={fps}><Chapter index={0}/></Series.Sequence>
<Series.Sequence name="Connected workspace" durationInFrames={720} premountFor={fps}><Chapter index={1}/></Series.Sequence>
<Series.Sequence name="Equipment" durationInFrames={720} premountFor={fps}><Chapter index={2}/></Series.Sequence>
<Series.Sequence name="Add equipment" durationInFrames={720} premountFor={fps}><Chapter index={3}/></Series.Sequence>
<Series.Sequence name="Search and filter" durationInFrames={720} premountFor={fps}><Chapter index={4}/></Series.Sequence>
<Series.Sequence name="Maintenance" durationInFrames={720} premountFor={fps}><Chapter index={5}/></Series.Sequence>
<Series.Sequence name="Log the work" durationInFrames={720} premountFor={fps}><Chapter index={6}/></Series.Sequence>
<Series.Sequence name="Laboratories" durationInFrames={720} premountFor={fps}><Chapter index={7}/></Series.Sequence>
<Series.Sequence name="Categories" durationInFrames={720} premountFor={fps}><Chapter index={8}/></Series.Sequence>
<Series.Sequence name="Accounts" durationInFrames={720} premountFor={fps}><Chapter index={9}/></Series.Sequence>
<Series.Sequence name="Connected workflow" durationInFrames={720} premountFor={fps}><Chapter index={10}/></Series.Sequence>
<Series.Sequence name="Keep moving forward" durationInFrames={720} premountFor={fps}><Chapter index={11}/></Series.Sequence>
</Series><Audio src={staticFile('music.wav')} premountFor={fps} volume={f=>interpolate(f,[0,30,8400,8640],[.5,.45,.45,0],{extrapolateRight:'clamp'})}/></AbsoluteFill>};
registerRoot(()=> <><Composition id="LabTracker" component={Film} durationInFrames={8640} fps={30} width={1920} height={1080}/><Composition id="Equipment" component={Chapter} defaultProps={{index:2}} durationInFrames={720} fps={30} width={1920} height={1080}/><Composition id="Maintenance" component={Chapter} defaultProps={{index:5}} durationInFrames={720} fps={30} width={1920} height={1080}/></>);
