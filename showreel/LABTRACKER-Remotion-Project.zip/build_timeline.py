import json
T=json.load(open('timing.json'));s=open('/workspace/labtracker-film/src/index.tsx').read().replace("from './Design'","from './Scene'")
for scene in T['scenes']:s=s.replace('durationInFrames={720}',f'durationInFrames={{{scene["frames"]}}}',1)
s=s.replace('durationInFrames={8640}',f'durationInFrames={{{T["frames"]}}}').replace("staticFile('music.wav')","staticFile('music-v2.wav')").replace('[0,30,8400,8640]',f'[0,30,{T["frames"]-60},{T["frames"]}]').replace('[.5,.45,.45,0]','[.3,.21,.21,0]')
# Keep standalone scene durations equal to their main timeline instances.
s=s.replace('durationInFrames={720}',f'durationInFrames={{{T["scenes"][2]["frames"]}}}',1).replace('durationInFrames={720}',f'durationInFrames={{{T["scenes"][5]["frames"]}}}',1)
open('src/index.tsx','w').write(s)
