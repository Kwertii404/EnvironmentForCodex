import json, os, numpy as np, soundfile as sf
from kokoro_onnx import Kokoro
os.environ['OMP_NUM_THREADS']='3'
k=Kokoro('/workspace/voice-models/kokoro-v1.0.onnx','/workspace/voice-models/voices-v1.0.bin')
data=json.load(open('chapters.json'))
for i,c in enumerate(data):
 p=f'public/voice-{i}.wav'
 if os.path.exists(p):continue
 a,sr=k.create(c['voice'],voice='af_heart',speed=1.03,lang='en-us')
 sf.write(p,a,sr)
 print(i,len(a)/sr,flush=True)
