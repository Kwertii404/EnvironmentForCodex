import numpy as np, soundfile as sf
import subprocess
music,sr=sf.read('public/music.wav',dtype='float32');n=len(music)
gain=np.full(n,.8,np.float32);voice=np.zeros(n,np.float32)
for i in range(12):
 subprocess.run(['ffmpeg','-v','error','-i',f'public/voice-{i}.wav','-ar',str(sr),'-y',f'/tmp/labtracker-voice-{i}.wav'],check=True)
 a,r=sf.read(f'/tmp/labtracker-voice-{i}.wav',dtype='float32')
 start=int((i*24+1)*sr);end=min(n,start+len(a));voice[start:end]+=a[:end-start]*1.3
 gain[start:end]=.32
 ramp=int(.3*sr);gain[max(0,start-ramp):start]=np.linspace(.8,.32,min(ramp,start));gain[end:min(n,end+ramp)]=np.linspace(.32,.8,min(ramp,n-end))
mix=music*gain[:,None]+voice[:,None]
sf.write('out/mix.wav',mix,sr)
