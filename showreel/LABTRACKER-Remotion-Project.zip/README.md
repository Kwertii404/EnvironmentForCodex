# LABTRACKER — narration-synchronized revision

A 4:52.433, 1920 × 1080, 30 fps revision of the LABTRACKER showreel.

## What changed

- Punchier narration generated with Kokoro ONNX v1.0: 65% `af_heart`, 35% `af_bella`, varied delivery rates, and a final 1.06× pacing adjustment without pitch shifting.
- 36 independently generated phrases. Their measured sample durations drive all 12 scene lengths and the three visual feature highlights in each scene.
- A new original 108 BPM instrumental with electric-piano voicings, melodic answers, bass, pads, percussion, breakdowns, and scene-aligned transition swells.
- Music ducks under speech; the final mix is mastered toward −16 LUFS with true-peak headroom.

## Preview and render

```sh
npm ci
npm run studio
npm run render
```

The render command uses `/usr/bin/chromium`; adjust it for your system. `src/Scene.tsx` maps the original Remotion animation onto measured narration cues. `timing.json` is the authoritative timeline; `beats.json` contains the spoken copy.

The delivered MP4 reuses the existing Remotion-rendered picture through the same piecewise retiming map in `edit_video.py`, finished with FFmpeg. This preserves the real UI footage and avoids rasterizing the existing graphics again.

## Audio reproduction

Install `kokoro-onnx`, NumPy and SoundFile in a Python virtual environment. `generate_voice.py` expects the upstream Kokoro v1.0 ONNX model and voices under `/workspace/voice-models`. Model weights are not included. All generated voice clips, music, and the finished audio master are included.

Run `generate_voice.py`, `finalize_timing.py`, `build_timeline.py`, then `score.py`. Do not rerun `finalize_timing.py` on clips already adjusted unless the saved originals under `out/unpaced` are available. To reproduce the master:

```sh
ffmpeg -i out/mix-v2.wav -af loudnorm=I=-16:TP=-1.8:LRA=8 -ar 48000 -c:a aac -b:a 256k out/master-v2.m4a
```

For direct Remotion rendering, replace the render's audio with `out/master-v2.m4a` using FFmpeg stream copying. For the editorial retime, set `src` in `edit_video.py` to the previous 4:48 MP4 and run the script, then concatenate its scene files with the same finished master.

The music is synthesized originally for this revision; no third-party song recording is used.

After `edit_video.py` completes, run `bash finish.sh` to concatenate scenes, regenerate constant-rate presentation timestamps, and attach the master. This finishing pass prevents container timestamp offsets at scene joins. Use an output filename that does not already exist, or add FFmpeg's `-y` flag when replacing a prior export.
