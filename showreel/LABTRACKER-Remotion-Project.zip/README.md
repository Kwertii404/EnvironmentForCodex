# LABTRACKER — product film

A 4:48, 1920 × 1080, 30 fps Remotion showreel built from the supplied LABTRACKER screen recording.

## Preview and render

```sh
npm ci
npm run studio
npm run render
```

The render script uses `/usr/bin/chromium`; change that CLI option if Chromium is installed elsewhere.

## Edit

- `src/index.tsx`: twelve individually named timeline chapters, each 24 seconds.
- `src/Design.tsx`: the common visual system, animated cameras, chapter graphics and media frames.
- `chapters.json`: chapter copy, feature labels, narration script and UI still selection.
- `public/`: extracted real UI stills, cropped motion clips, Kokoro narration, and music.

UI assets are captures of the supplied recording, not recreated interfaces. Browser chrome, the taskbar, and failed sign-in attempts are excluded. Some source text is compressed by the original recording.

## Audio

Narration was generated locally with Kokoro ONNX v1.0, `af_heart`, at speed 1.03. `make_voice.py` reproduces it with `kokoro-onnx` and the upstream model and voice files under `/workspace/voice-models`. Models are not included in the project archive; the generated narration is included.

`make_music.py` creates the original 100 BPM electronic instrumental using synthesized pads, arpeggios, bass, percussion and transition swells. No third-party music recording is used.

No deployment or environment publication is required to use these files.

## Final mastering

`master_audio.py` combines the generated voice clips with music, with music ducking under speech. Run it with a Python environment containing NumPy and SoundFile, then:

```sh
ffmpeg -i out/mix.wav -af loudnorm=I=-16:TP=-1.5:LRA=9 -ar 48000 -c:a aac -b:a 256k out/master.m4a
bash finish.sh
```

The supplied final MP4 uses this mastered soundtrack. The prebuilt master is included in the archive so finishing can also run without regenerating audio.
