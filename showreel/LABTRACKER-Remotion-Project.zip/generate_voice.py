import os,json,numpy as np,soundfile as sf
from kokoro_onnx import Kokoro
k=Kokoro('/workspace/voice-models/kokoro-v1.0.onnx','/workspace/voice-models/voices-v1.0.bin')
v=.65*k.voices['af_heart']+.35*k.voices['af_bella']
beats=json.load(open('beats.json')); scenes=[];cursor=0
for i,lines in enumerate(beats):
 chunks=[];cues=[];pos=20/30
 for j,line in enumerate(lines):
  p=f'public/vo-{i}-{j}.wav'
  if os.path.exists(p):a,sr=sf.read(p,dtype='float32')
  else:
   a,sr=k.create(line,voice=v,speed=[1.04,1.07,1.03][j],lang='en-us',sentence_pause=.15,clause_pause=.07);sf.write(p,a,sr)
  # cue boundaries are measured sample durations, not text-length estimates
  cues.append({'start':round(pos*30),'duration':len(a)/sr,'file':p.split('/')[-1],'text':line})
  pos+=len(a)/sr+.24
 frames=int(np.ceil((pos+.7)*30));scenes.append({'index':i,'from':cursor,'frames':frames,'cues':cues});cursor+=frames
 print(i,frames/30,flush=True)
json.dump({'frames':cursor,'fps':30,'scenes':scenes},open('timing.json','w'),indent=2)
print('TOTAL',cursor/30,flush=True)
